package com.example.todoapp1;

public class MainData {

    private String tv_todo, tv_memo;

    public MainData(String tv_todo, String tv_memo) {
        this.tv_todo = tv_todo;
        this.tv_memo = tv_memo;
    }

    public String getTv_todo() {
        return tv_todo;
    }

    public void setTv_todo(String tv_todo) {
        this.tv_todo = tv_todo;
    }

    public String getTv_memo() {
        return tv_memo;
    }

    public void setTv_memo(String tv_memo) {
        this.tv_memo = tv_memo;
    }
}
